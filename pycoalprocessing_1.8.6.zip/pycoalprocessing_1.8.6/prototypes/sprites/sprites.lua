data:extend(
{
  {
    type = "sprite",
    name = "pywiki",
    filename = "__pycoalprocessinggraphics__/graphics/py-wiki.png",
    --priority = "extra-high-no-scale",
    width = 128,
    height = 128,
    --flags = {"gui-icon"},
    --mipmap_count = 1,
    --scale = 0.5
  }
}
)
